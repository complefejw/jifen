﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;

namespace 消防积分获取
{
    public class HttpHelp
    {
        //HttpClient,异步Post
        public bool PostAsync(string url, Dictionary<string, string> myDictionary, string postParaJsonStr, ref string outResStr)
        {
            bool res = false;
            var handler = new HttpClientHandler()
            {
                AutomaticDecompression = DecompressionMethods.GZip,
            };
            try
            {
                using (var http = new HttpClient(handler))
                {
                    string postPara = postParaJsonStr;
                    using (HttpContent content = new StringContent(postPara))
                    {
                        content.Headers.ContentType = new MediaTypeHeaderValue("application/json;charset=UTF-8");
                        foreach (var item in myDictionary)
                        {
                            content.Headers.Add(item.Key, item.Value);
                        }
                        var response = http.PostAsync(url, content).Result;
                        outResStr = response.Content.ReadAsStringAsync().Result;
                        res = response.IsSuccessStatusCode;
                    }
                };
            }
            catch (Exception ex)
            {
                outResStr = ex.Message;
                res = false;
            }
            return res;
        }

        //HttpClient,异步Get
        public bool GetAsync(string url, Dictionary<string, string> myDictionary, string postParaStr, ref string outResStr)
        {
            bool res = false;
            var handler = new HttpClientHandler()
            {
                AutomaticDecompression = DecompressionMethods.GZip
            };
            try
            {
                using (var http = new HttpClient(handler))
                {
                    using (HttpContent content = new StringContent(postParaStr))
                    {
                        content.Headers.ContentType = new MediaTypeHeaderValue("application/json;charset=UTF-8");
                        foreach (var item in myDictionary)
                        {
                            content.Headers.Add(item.Key, item.Value);
                        }
                        var response = http.GetAsync(url + "?" + postParaStr).Result; // postParaStr 注意拼接好
                        outResStr = response.Content.ReadAsStringAsync().Result;
                        res = response.IsSuccessStatusCode;
                    }
                };
            }
            catch (Exception ex)
            {
                outResStr = ex.Message;
                res = false;
            }
            return res;
        }

        //WebRequest同步Post
        public static string HttpPost(string Url, Dictionary<string, string> myDictionary, string postDataStr, ref string outResStr)
        {
            try
            {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(Url);
                request.Method = "POST";
                request.ContentType = "application/json;charset=UTF-8";
                foreach (var item in myDictionary)
                {
                    request.Headers.Add(item.Key, item.Value);
                }
                Encoding encoding = Encoding.UTF8;
                byte[] postData = encoding.GetBytes(postDataStr);
                request.ContentLength = postData.Length;
                Stream myRequestStream = request.GetRequestStream();
                myRequestStream.Write(postData, 0, postData.Length);
                myRequestStream.Close();
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                Stream myResponseStream = response.GetResponseStream();
                StreamReader myStreamReader = new StreamReader(myResponseStream, encoding);
                string retString = myStreamReader.ReadToEnd();
                myStreamReader.Close();
                myResponseStream.Close();

                return retString;
            }
            catch (Exception)
            {
                return null;
            }
            
        }

        //WebRequest同步Get
        public static string HttpGet(string Url, Dictionary<string, string> myDictionary, string postDataStr)
        {
            try
            {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(Url + (postDataStr == "" ? "" : "?") + postDataStr);
                request.Method = "GET";
                request.ContentType = "text/html;charset=UTF-8";
                foreach (var item in myDictionary)
                {
                    request.Headers.Add(item.Key, item.Value);
                }
                request.UserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36";
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                Stream myResponseStream = response.GetResponseStream();
                StreamReader myStreamReader = new StreamReader(myResponseStream, Encoding.GetEncoding("utf-8"));
                string retString = myStreamReader.ReadToEnd();
                myStreamReader.Close();
                myResponseStream.Close();
                return retString;
            }
            catch (Exception)
            {
                return null;
            }

        }
    }
}